package com.mercurio.game.Screen;

public class Constant {
    public static final String MENU_SCREEN = "Menu";
    public static final String CASA_ASH = "mappa/PrimaCasa.tmx";
    public static final String CASA_ASH_SCREEN = "CasaSpawn";
}
